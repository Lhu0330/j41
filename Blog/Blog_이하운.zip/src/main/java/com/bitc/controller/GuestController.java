package com.bitc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bitc.dto.BlogGuestDto;
import com.bitc.service.BlogGuestService;

@Controller
public class GuestController {

	@Autowired
	private BlogGuestService BlogGuestService;

	
	@RequestMapping(value="/blog/guest" , method=RequestMethod.GET)
	public ModelAndView openBlogGuestList() throws Exception {
		ModelAndView mv = new ModelAndView("/main/GuestWrite");
		List<BlogGuestDto> GuestList = BlogGuestService.selectBlogGuestList();
		mv.addObject("GuestList", GuestList); 
		return mv;
	}
	
//	@RequestMapping("/blog/writeAddress.do")
//	public String writeBlog() throws Exception {
//		return "/Address/writeAddress";
//	}
//	
	@RequestMapping("/blog/guestInsert")
	public String insertBlogGuest(BlogGuestDto guest) throws Exception {
		BlogGuestService.insertBlogGuest(guest);
		
		return "redirect:/blog/guest";
	}
	
	@RequestMapping("/blog/guestDelete")
	public String deleteBlog(@RequestParam("seq") int seq, @RequestParam("guestPw") String guestPw) throws Exception {
		BlogGuestService.deleteBlogGuest(seq, guestPw);
		return "redirect:/blog/guest";
	}
}













