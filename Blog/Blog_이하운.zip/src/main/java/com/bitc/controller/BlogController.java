package com.bitc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bitc.dto.BlogWriteDto;
import com.bitc.service.BlogService;

@Controller
public class BlogController {

	@Autowired
	private BlogService BlogService;
	
	@RequestMapping("/")
	public String index() throws Exception {
		return "/main/BlogMain";
	}
	
	
	@RequestMapping(value="/blog" , method=RequestMethod.GET)
	public ModelAndView openBlogList() throws Exception {
		ModelAndView mv = new ModelAndView("/main/BlogMain");
		List<BlogWriteDto> blogList = BlogService.selectBlogList();
		mv.addObject("blogsList", blogList); 
		return mv;
	}
	
	@RequestMapping("/blog/write")
	public String writeBlog() throws Exception {
		return "/main/BlogWrite";
	}
	
	@RequestMapping("/blog/writeInsert")
	public String insertBlog(BlogWriteDto blog) throws Exception {
		BlogService.insertBlog(blog);
		
		return "redirect:/blog";
	}
	
	@RequestMapping("/blog/detail")
	public ModelAndView selectBlogDetail(@RequestParam("idx") int idx) throws Exception {
		ModelAndView mv = new ModelAndView("/main/BlogDetail");
		
		BlogWriteDto blog = BlogService.selectBlogDetail(idx);
		mv.addObject("blog", blog);
		
		return mv;
	}
	
	@RequestMapping("/blog/blogUpdate")
	public String updateBlog(BlogWriteDto blog) throws Exception {
		BlogService.updateBlog(blog);
		return "redirect:/blog";
	}
	
	@RequestMapping("/blog/blogDelete")
	public String deleteBlog(@RequestParam("idx") int idx) throws Exception {
		BlogService.deleteBlog(idx);
		return "redirect:/blog";
	}
}













