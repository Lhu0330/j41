package com.bitc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitc.dto.BlogWriteDto;
import com.bitc.mapper.BlogMapper;

// 내부에서 자바 로직을 처리하는 어노테이션
// 지정한 interface 대신 실행하는 의미
@Service
public class BlogServiceImpl implements BlogService {

	@Autowired
	private BlogMapper BlogMapper;
	
//	부모인 AddressService 인터페이스가 가지고 있는 추상 메서드를 재정의
	@Override
	public List<BlogWriteDto> selectBlogList() throws Exception {
//		mybatis와 연결되어 있는 AddressMapper를 이용하여 실제 데이터베이스에서 데이터를 조회
		return BlogMapper.selectBlogList();
	}
	
//	부모인 AddressService 인터페이스가 가지고 있는 추상 메서드를 재정의
	@Override
	public void insertBlog(BlogWriteDto blog) throws Exception {
//		DB를 조작하는 Mapper의 insertAddress()메서드를 사용하여 실제 DB에 데이터를 추가함
		BlogMapper.insertBlog(blog);
	}
	
	@Override
	public BlogWriteDto selectBlogDetail(int idx) throws Exception {
		BlogWriteDto blog = BlogMapper.selectBlogDetail(idx);
		
		return blog;
	}
	
	@Override
	public void deleteBlog(int idx) throws Exception {
		BlogMapper.deleteBlog(idx);
	}
	
	@Override
	public void updateBlog(BlogWriteDto blog) throws Exception {
		BlogMapper.updateBlog(blog);
	}
}








