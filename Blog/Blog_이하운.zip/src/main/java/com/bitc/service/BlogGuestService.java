package com.bitc.service;

import java.util.List;

import com.bitc.dto.BlogGuestDto;

// Controller에서 사용할 비지니스 로직의 사용방법을 제공
public interface BlogGuestService {

//	게시판의 게시글 목록을 불러오는 추상 메서드
	List<BlogGuestDto> selectBlogGuestList() throws Exception;
	
//	DB에 게시글 추가하는 추상 메서드
	void insertBlogGuest(BlogGuestDto guest) throws Exception;
	
//	지정한 게시글을 DB에서 삭제하는 추상 메서드
	void deleteBlogGuest(int seq, String guestPw) throws Exception;
}
