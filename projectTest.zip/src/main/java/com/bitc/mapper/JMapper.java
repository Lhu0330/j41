package com.bitc.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.bitc.dto.JDto;

@Mapper
public interface JMapper {

	public List<JDto> selectCartList() throws Exception;
	
	public List<JDto> selectSuccessList() throws Exception;
	
	public JDto selectCostCalculate(JDto cart) throws Exception;

	public void insertCart(JDto cart) throws Exception;

	public void deleteCart(int productIdx) throws Exception;

	void updateCart(JDto cart) throws Exception;
	
	void updateSuccess(JDto success) throws Exception;

}
